#!/bin/bash
# provision_client.sh — Configure M1/M2 to use G1 as DNS server

set -e
echo "========================================="
echo " Provisioning Client: $(hostname)"
echo "========================================="

# Point DNS to G1
echo "[1/2] Setting DNS server to G1 (192.168.10.1)..."
sudo tee /etc/resolv.conf << 'EOF'
search domain.com
nameserver 192.168.10.1
EOF

# Install dns utils for testing
echo "[2/2] Installing bind-utils (nslookup, dig)..."
sudo yum install -y bind-utils

echo ""
echo "========================================="
echo " Client provisioning complete!"
echo " DNS server: 192.168.10.1"
echo " Test with: nslookup m1.domain.com"
echo "========================================="
