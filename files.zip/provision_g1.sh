#!/bin/bash
# provision_g1.sh — Install and configure DNS (BIND9) + DHCP on G1

set -e
echo "========================================="
echo " Provisioning G1: DNS + DHCP Server"
echo "========================================="

# ── Install packages ──────────────────────────────────────────────────────
echo "[1/5] Installing bind and dhcp-server..."
sudo yum install -y bind bind-utils dhcp-server

# ── DNS: named.conf ───────────────────────────────────────────────────────
echo "[2/5] Configuring DNS (named.conf)..."
sudo tee /etc/named.conf << 'EOF'
options {
    listen-on port 53 { any; };
    directory "/var/named";
    allow-query { any; };
    recursion yes;
    forwarders { 8.8.8.8; };
    dnssec-validation no;
};

zone "domain.com" IN {
    type master;
    file "/var/named/forward.domain.com.db";
};

zone "10.168.192.in-addr.arpa" IN {
    type master;
    file "/var/named/reverse.domain.com.db";
};

include "/etc/named.rfc1912.zones";
include "/etc/named.root.key";
EOF

# ── DNS: Forward zone ─────────────────────────────────────────────────────
echo "[3/5] Creating DNS zone files..."
sudo tee /var/named/forward.domain.com.db << 'EOF'
$TTL 86400
@   IN  SOA     ns1.domain.com. root.domain.com. (
                    2026051401
                    3600
                    1800
                    604800
                    86400 )
@       IN  NS      ns1.domain.com.
ns1     IN  A       192.168.10.1
g1      IN  A       192.168.10.1
m1      IN  A       192.168.10.11
m2      IN  A       192.168.10.12
www     IN  A       192.168.10.1
EOF

sudo tee /var/named/reverse.domain.com.db << 'EOF'
$TTL 86400
@   IN  SOA     ns1.domain.com. root.domain.com. (
                    2026051401
                    3600
                    1800
                    604800
                    86400 )
@       IN  NS      ns1.domain.com.
1       IN  PTR     g1.domain.com.
11      IN  PTR     m1.domain.com.
12      IN  PTR     m2.domain.com.
EOF

# Fix permissions so named can read zone files
sudo chown named:named /var/named/forward.domain.com.db
sudo chown named:named /var/named/reverse.domain.com.db
sudo chmod 640 /var/named/forward.domain.com.db
sudo chmod 640 /var/named/reverse.domain.com.db

# ── DHCP: dhcpd.conf ──────────────────────────────────────────────────────
echo "[4/5] Configuring DHCP (dhcpd.conf)..."
sudo tee /etc/dhcp/dhcpd.conf << 'EOF'
default-lease-time 600;
max-lease-time 7200;
authoritative;

subnet 192.168.10.0 netmask 255.255.255.0 {
    range 192.168.10.100 192.168.10.200;
    option routers 192.168.10.1;
    option subnet-mask 255.255.255.0;
    option domain-name "domain.com";
    option domain-name-servers 192.168.10.1;
}

host M1 {
    hardware ethernet 08:00:27:d5:c3:0b;
    fixed-address 192.168.10.11;
}

host M2 {
    hardware ethernet 08:00:27:a8:09:48;
    fixed-address 192.168.10.12;
}
EOF

# ── Start services ────────────────────────────────────────────────────────
echo "[5/5] Starting and enabling services..."
sudo systemctl enable --now named
sudo systemctl enable --now dhcpd

echo ""
echo "========================================="
echo " G1 provisioning complete!"
echo " DNS  → named  (port 53)"
echo " DHCP → dhcpd  (port 67)"
echo "========================================="
